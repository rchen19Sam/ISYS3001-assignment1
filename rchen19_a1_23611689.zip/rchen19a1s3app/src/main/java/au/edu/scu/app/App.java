package au.edu.scu.app;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Response;
import software.amazon.awssdk.services.s3.model.S3Object;



/**
 * This class is a example of sending and retriving data.
 * @Author: ChenRong
 * @Version 1.0.0
 * 
 */
public class App 
{
    public static S3Client s3;
    
    public static void main( String[] args )
    {
        App app = new App();
        app.createObject();
        app.readJsonFile();
    }
    
    
    /**
    * This method is used to upload a json string as a json file.
    * Method 
    * @Author:ChenRong
    */
    public void createObject(){
        String bucket = "rchen19-a1-s3bucket";
        Region region = Region.US_EAST_1;
        try{
            s3 = S3Client.builder().region(region).build();
            //New json file name
            String key = "student.json";
            //The text in the json file
            String text = "[{\"name\": \"A\", \"age\": 25, \"city\": \"Gold Coast\"}, {\"name\": \"B\", \"age\": 56, \"city\":\"Brisbane\"}, {\"name\": \"D\", \"age\": 12, \"city\": \"Melbourne\"}, {\"name\": \"Z\", \"age\": 19,\"city\": \"Sydney\"}]";
            byte bytes[] = text.getBytes();
            ByteBuffer data = ByteBuffer.wrap(bytes);
            
            PutObjectRequest req = PutObjectRequest.builder().bucket(bucket).key(key).build();
            PutObjectResponse resp = s3.putObject(req, RequestBody.fromByteBuffer(data));
            
            
        }
        catch(S3Exception exp){
            System.out.println("Error: "+ exp.awsErrorDetails().errorMessage());
        }
    }
    
    /**
     * This method is used to read a file from s3 bucket and save to the local storage.
     * @Author:ChenRong
     */
    public void readJsonFile(){
        String bucket = "rchen19-a1-s3bucket";
        String key = "student.json";
        Region region = Region.US_EAST_1;
        try {
            s3 = S3Client.builder().region(region).build();
        
            Path path = FileSystems.getDefault().getPath("temp.txt");
        
            GetObjectRequest req = GetObjectRequest.builder().bucket(bucket).key(key).build();
            GetObjectResponse resp = s3.getObject(req, path);
        } 
        catch(S3Exception exp) {
            System.out.println("Error: "+ exp.awsErrorDetails().errorMessage());
        }
    }
}


