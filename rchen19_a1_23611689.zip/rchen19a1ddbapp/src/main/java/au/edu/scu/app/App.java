package au.edu.scu.app;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;


import software.amazon.awssdk.services.dynamodb.model.PutItemRequest;

import software.amazon.awssdk.services.dynamodb.model.ScanRequest;
import software.amazon.awssdk.services.dynamodb.model.ScanResponse;
import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;


import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.io.IOException;
/**
 * This class is used to add data to the database and read the data from the database
 * @Auther: ChenRong
 * @Version: 1.0.0
 *
 */
public class App 
{
    private DynamoDbClient ddb;
    private String table = "Car";
    
    public static void main( String[] args )
    {
        App app = new App();
        app.insertItems();
        app.readItems();
    }
    
    public App(){
        ddb = DynamoDbClient.create();
    }
    
    /**
    * This method is used to insert data to the database
    * Method 
    * @Author:ChenRong
    */
    public void insertItems(){
        int id = 1;
        int year = 2021;
        try{
            for(int i = 0; i< 10; i++){
                // create a new item
                HashMap<String, AttributeValue> put_key = new HashMap<String,AttributeValue>();
                    put_key.put("Id", AttributeValue.builder().n(""+id).build());
                    put_key.put("Model", AttributeValue.builder().s("Tesla").build());
                    put_key.put("Make", AttributeValue.builder().s("America").build());
                    put_key.put("Year", AttributeValue.builder().n(""+year).build());
                    put_key.put("Colour", AttributeValue.builder().s("Grey").build());
                    // create put request object
                    PutItemRequest req = PutItemRequest.builder().tableName(table).item(put_key).build();
                    // now make the put request
                    ddb.putItem(req);
                    id++;
            }
        } catch(DynamoDbException e){
            System.err.println("Exception on get operation: "+e.getMessage());
            System.exit(-1);
        }
    }
    
    
    /**
    * This method is used to read the data from the database
    * Method 
    * @Author:ChenRong
    */
    public void readItems(){
        // build key for get operation
        HashMap<String, AttributeValue> read_key = new HashMap<String,AttributeValue>();
        for(int i = 1; i<11; i++){
            read_key.put("Id", AttributeValue.builder().n(""+i).build());
            // build a table request object
            GetItemRequest req = GetItemRequest.builder().key(read_key).tableName(table).build();
                try {
                    // do the item request
                    Map<String,AttributeValue> item = ddb.getItem(req).item();
                    if (item != null) {
                        Set<String> keys = item.keySet();
                        for (String k: keys) {
                            AttributeValue attv = item.get(k);
                            switch (k) {
                                case "Id":
                                    System.out.println("Unit code: "+attv.n());
                                    break;
                                case "Model":
                                    System.out.println("Model: "+ attv.s());
                                    break;
                                case "Make":
                                    System.out.println("Make: "+ attv.s());
                                    break;
                                case "Year":
                                    System.out.println("Year: "+ attv.n());
                                    break;
                                case "Colour":
                                    System.out.println("Colour: "+ attv.s());
                                    break;
                                default:
                                    System.out.println("Unknown attribute: "+k);
                                    break;
                            }
                        }
                    } else {
                        System.err.println("No item found with key: "+i);
                    }
                    } catch (DynamoDbException e) {
                     System.err.println("Exception on get operation: "+e.getMessage());
                     System.exit(-1);
                    }
        }
    }
}
